package iss.java.mail;
import org.reflections.Reflections;

import java.io.IOException;
import java.util.Random;
import java.util.Set;

import javax.mail.MessagingException;


public class HomeworkLoader {
    public static void main(String[] args) throws MessagingException, IOException, InterruptedException, IllegalAccessException, InstantiationException {
        Reflections reflections = new Reflections("iss.java.mail");
        Set<Class<? extends IMailService>> impls = reflections.getSubTypesOf(IMailService.class);
        Class<? extends IMailService> homework = impls.iterator().next();
    	//MyMail2014302580205 homework=new MyMail2014302580205();
        IMailService service =  homework.newInstance();
        service.connect();
        String name = homework.getName();
        String id = String.valueOf(name.length()-13);
        System.out.println(id);
        
        int random = new Random().nextInt(3);
        System.out.println("mail ID: "+random);
        
        service.send("issjava2015@foxmail.com", "java��ҵ"+random+"_"+id,"����");
        System.out.println("mail sent");
        for(int i = 0;i<30;i++){
            if(service.listen()){
                System.out.println(service.getReplyMessageContent("issjava2015@163.com","�Զ��ظ���java��ҵ"+random+"_"+id));
                System.out.println("check if your mail id and verify id match");
                return;
            }
            System.out.println("waiting for auto reply");
            Thread.sleep(5000);
        }
        System.out.println("time out");
    }
}
