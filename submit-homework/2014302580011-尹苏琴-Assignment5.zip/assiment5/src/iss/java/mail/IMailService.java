package iss.java.mail;

import javax.mail.MessagingException;
import java.io.IOException;

/**
 * Define the progress of sending and receiving mails
 */
public interface IMailService {
    /**
     * Init and connect all the sever
     * @throws MessagingException
     */
    public void connect() throws MessagingException;

    /**
     * Send a message
     * @param recipient the address of the recipient
     * @param subject the subject of the mail
     * @param content the main contenet of the mail
     * @throws MessagingException
     */
    public void send(String recipient, String subject, Object content) throws MessagingException;

    /**
     * Ask the server wheather there is a new mail
     * @return a boolean to check if there is a new unread mail
     * @throws MessagingException
     */
    public boolean listen() throws MessagingException;

    /**
     * Receive the auto replyment and cast into string
     * Any method to receive is acceptable,even without such 2 parametres
     * @param sender The sender's address
     * @param subject The subject of the auto replyment
     * @return The content of the auto replyment
     * @throws MessagingException
     * @throws IOException
     */
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException;
}
