package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;


public class Email_Autherticator2014302580011 extends Authenticator {


    String username = "lscjr12345@163.com"; // eg:123@qq.com
    String password = "ykqmnveghhgfblcc";

    public Email_Autherticator2014302580011() {
        super();
    }

    public Email_Autherticator2014302580011(String user, String pwd) {
        super();
        username = user;
        password = pwd;
    }


    /*This class is to check the password and the username*/
    public PasswordAuthentication getPasswordAuthentication()
    {
        return new PasswordAuthentication(username, password);
    }

}
