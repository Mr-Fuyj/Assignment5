package iss.java.mail;

import java.io.IOException;
import java.util.Properties;
import javax.mail.*;
import javax.mail.Authenticator;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class Mail2014302580011 implements IMailService {

    private String imaphost = "imap.163.com";

    private String smtphost = "smtp.163.com";

    private MailSetting2014302580011 mailInfo = new MailSetting2014302580011();

    private Session session;

    private Properties props = new Properties();

    private MimeMessage message;



    @Override
    public void connect() throws MessagingException{
        props.clear();
        Authenticator auth = new Email_Autherticator2014302580011();
        props.put("mail.smtp.host", smtphost);
        props.put("mail.smtp.auth", "true");
        session = Session.getDefaultInstance(props, auth);
    }


    @Override
    public void send(String recipient,String subject,Object content) throws MessagingException {

        try {
            mailInfo = (MailSetting2014302580011) content;
            message = new MimeMessage(session);
            message.setContent("Hello", "text/plain");
            message.setSubject(subject);
            message.setText(mailInfo.getMail_body());
            message.setHeader(mailInfo.getMail_head_name(), mailInfo.getMail_head_value());//设置邮件标题
            Address address = new InternetAddress(mailInfo.getMail_from(), mailInfo.getPersonalName());
            message.setFrom(address);
            Address toaddress = new InternetAddress(recipient);
            message.addRecipient(Message.RecipientType.TO, toaddress);
            System.out.println(message);
            Transport.send(message);
            System.out.println("Send Mail Ok!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean listen() throws MessagingException {

        props.clear();
        props.put("mail.store.protocol", "imap");
        props.put("mail.imap.host", this.imaphost);
        Authenticator auth = new Email_Autherticator2014302580011();
        session = Session.getDefaultInstance(props,auth);
        Store store = session.getStore();
        store.connect();

        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);


        int numberOfUnread = folder.getUnreadMessageCount();
        if (numberOfUnread==0){
            System.out.println("You hava no unread mail");
            return false;
        }else {
            System.out.println("You have " + numberOfUnread + " mails");
            return true;
        }


    }

    @Override
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
        props.clear();
        props.put("mail.store.protocol", "imap");
        props.put("mail.imap.host", this.imaphost);
        Authenticator auth = new Email_Autherticator2014302580011();
        session = Session.getDefaultInstance(props,auth);
        String content = "No such mail with such subject";

        Store store = session.getStore();
        store.connect();

        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);

        Message[] messages = folder.getMessages();
        for (int i = 0; i<messages.length;i++){
            Message message = messages[i];
            if (subject.equals(message.getSubject())){
                content = message.getContent().toString();
            }
        }

        return content;
    }


}