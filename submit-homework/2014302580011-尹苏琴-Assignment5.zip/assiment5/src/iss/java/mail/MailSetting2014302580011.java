package iss.java.mail;

/**
 * Created by Administrator on 2015/11/18.
 */
public class MailSetting2014302580011 {

    private String mail_head_name = "this is head of this mail";

    private String mail_head_value = "this is head of this mail";

    /*private String mail_to = "lscjr12345@163.com";*/

    private String mail_from = "lscjr12345@163.com";

    /*private String mail_subject = "this is the subject of this test mail";*/

    private String mail_body = "this is mail_body of this test mail";

    private String personalName = "我的邮件";

    public String getMail_from() {
        return mail_from;
    }

    /*public String getMail_subject() {
        return mail_subject;
    }*/

    public String getPersonalName() {
        return personalName;
    }


    public String getMail_body() {
        return mail_body;
    }

    public String getMail_head_name() {
        return mail_head_name;
    }

    public String getMail_head_value() {
        return mail_head_value;
    }

    /*public String getMail_to() {
        return mail_to;
    }*/

    public void setMail_body(String mail_body) {
        this.mail_body = mail_body;
    }

    public void setMail_from(String mail_from) {
        this.mail_from = mail_from;
    }
}
